// made by Jack Hennessy

package uts.isd.model;

/**
 *
 * @author jhennessy18
 */
public class AccessLog {
    private String accessID;
    private String email;
    private String timestamp;
    
    public AccessLog(String accessID, String timestamp) {
        this.accessID = accessID;
        this.timestamp = timestamp;
    }
    
    public AccessLog(String accessID, String timestamp, String email) {
        this.accessID = accessID;
        this.timestamp = timestamp;
        this.email = email;
    }

    public String getAccessID() {
        return accessID;
    }

    public void setAccessID(String accessID) {
        this.accessID = accessID;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }
    
}
