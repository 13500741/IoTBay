/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package IoTBaysystem;


public class User implements java.io.Serializable {
    private String name;
    private String email;
    private String userType;
    private int contactNumber;
    private String password;
    private int userID;
    public User(){}
    public User(String name,String email, String userType, int contactNumber, String password, int userID)
    {
    this.name = name;
    this.email = email;
    this.userType = userType;
    this.contactNumber = contactNumber;
    this.password = password;
    this.userID = userID;
    }
    public String getName() 
    {
    return this.name;
    }
    public void setName (String name) 
    {
    this.name = name;
    } 
    public String getEmail() 
    {
    return this.email;
    }
    public void setEmail (String email) 
    {
    this.email = email;
    } 
    public String getUserType() 
    {
    return this.userType;
    }
    public void setUserType (String userType) 
    {
    this.userType = userType;
    }
    public int getContactNumber() 
    {
    return this.contactNumber;
    }
    public void setCntactNumber (int contactNumber) 
    {
    this.contactNumber = contactNumber;
    }
    public String getPassword() 
    {
    return this.password;
    }
    public void setPassword (String password) 
    {
    this.password = password;
    }
    public int getUserID() {
        return this.userID;
    }
    public void setUserID(int userID) {
        this.userID = userID;
    }
}
